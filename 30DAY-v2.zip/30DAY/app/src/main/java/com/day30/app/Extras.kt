package com.day30.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.webkit.JavascriptInterface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Util {
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
}

class Bridge(private val ctx: Context) {
    @JavascriptInterface
    fun steps(): Int {
        val p = ctx.getSharedPreferences("steps", Context.MODE_PRIVATE)
        return if (p.getString("day", "") == Util.today()) p.getInt("steps", 0) else -1
    }

    @JavascriptInterface
    fun setReminder(h: Int, m: Int, on: Boolean) {
        Reminder.schedule(ctx, h, m, on)
    }
}

object Reminder {
    const val CH = "remind"

    fun schedule(ctx: Context, h: Int, m: Int, on: Boolean) {
        ctx.getSharedPreferences("rem", Context.MODE_PRIVATE).edit()
            .putInt("h", h).putInt("m", m).putBoolean("on", on).apply()
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, 7, Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (!on) return
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        c.set(Calendar.SECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent?) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(Reminder.CH, "التذكير اليومي", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, Reminder.CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("30 DAY - محمد أزهر")
            .setContentText("لا تكسر الشعلة، سجّل إنجاز اليوم")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(2, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent?) {
        val p = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        if (p.getBoolean("on", false)) Reminder.schedule(ctx, p.getInt("h", 20), p.getInt("m", 0), true)
    }
}

class StepService : Service(), SensorEventListener {
    private var sm: SensorManager? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("steps", "عداد الخطوات", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "steps")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("30 DAY - محمد أزهر")
            .setContentText("عداد الخطوات يعمل")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        } else {
            startForeground(1, n)
        }
        val s = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm = s
        val sensor = s.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (sensor != null) s.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onDestroy() {
        sm?.unregisterListener(this)
        super.onDestroy()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val total = e.values[0].toLong()
        val p = getSharedPreferences("steps", Context.MODE_PRIVATE)
        val day = Util.today()
        var base = p.getLong("base", total)
        var carry = p.getLong("carry", 0L)
        val last = p.getLong("last", total)
        if (p.getString("day", "") != day) {
            base = total
            carry = 0L
        } else if (total < last) {
            carry += last - base
            base = total
        }
        val steps = (carry + (total - base)).toInt()
        p.edit().putString("day", day).putLong("base", base).putLong("carry", carry)
            .putLong("last", total).putInt("steps", steps).apply()
    }
}
