plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.day30.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.day30.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    signingConfigs {
        create("release") {
            storeFile = file(System.getenv("KS_PATH") ?: "missing.jks")
            storePassword = System.getenv("KS_PASS")
            keyAlias = "day30"
            keyPassword = System.getenv("KS_PASS")
        }
    }
    buildTypes {
        release { signingConfig = signingConfigs.getByName("release") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
